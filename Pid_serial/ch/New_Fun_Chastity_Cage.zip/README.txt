                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2841736
New Fun Chastity Cage by JosieLynn is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Loosely based on the "No Fun Chastity Cage", completely redrawn in Fusion 360, and added a lock hole for magic locker support.  If you don't have an actual lock, use the "Dummy Magic Locker" by deprav3d.

Three Ring sizes to choose from (sizes approximate based on area as they are not circular)
Small - ~44mm
Medium - ~48mm
Large - ~52mm

Two Cage lengths - don't overestimate how much room you need!

Base file contains the medium ring and large cage, grab the other files as necessary.

Parts will require sanding and finishing.  Print the ring with 5+ perimiters and 4 top shells for a durable piece.  Very strong if printed in PETG.

EDIT 3/29/2018 - Added 3 enclosed tube sizes to fulfill a request.  I have not printed or tried these yet, so any feedback is welcome.

Small Tube - ~36mm from base to tip
Medium Tube - ~50mm from base to tip
Large Tube - ~88mm from base to tip (may want to rotate this -25 degrees to print the supports up the middle to the tip)

EDIT 3/30/2018 - Added an additional ring size between Medium and Large.  Has the size embossed on the bottom of the ring, which will get added to the remainder of the rings eventually.

Ring - 50 - ~ 50mm

EDIT 3/31/2018 - Reworked each of the rings so the lock pillars are stronger, and no longer requires the wings along the side.  Rounded out the bottom of each ring, and renamed the small, medium and large rings to include their size

EDIT 4/7/2016 - Added "novelty" cage, which is the small tube internally, with a large strap-on on the outside.  Please remember many plastics are not body-safe and to be smart about what you do with these parts.